package com.example.proj042;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity<Activity> extends Activity {
    Button btnGo;
    EditText txtMsg;
    String msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtMsg=(EditText)findViewById(R.id.txtMsg);
        btnGo=(Button)findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog dialBox= createDialogBox();
                dialBox.show();
                txtMsg.setText("I am here!");
            }
        });
    }//oncreate

    private AlertDialog createDialogBox() {
        AlertDialog myQuittingDialogBox=
                new AlertDialog.Builder(this)
                        .setTitle("Terminator")
                        .setMessage("Are you sure that you want to quit?")
                        .setIcon(R.drawable.ic_menu_end_conversation)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                msg = "yes" + Integer.toString(i);
                                txtMsg.setText(msg);
                            }
                        })
                        .setNeutralButton("calcel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                msg="NO"+Integer.toString(i);
                                txtMsg.setText(msg);
                            }
                        })
                        .create();
       .return myQuittingDialogBox;
    }
}